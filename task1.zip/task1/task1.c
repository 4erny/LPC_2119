//working with pulling up resistor.

#include <LPC21xx.h>

unsigned int SW;
unsigned int i;

int main(void)
{
	SW = IO0PIN & 0x00000001;

	PINSEL0 = 0x00000000;
	IODIR0 = 0x7FFFFFF8; // pin 0.31 input pin0.0-0.3 input. rest is input.
	
if (SW == 0x00000001) //in case when switch connected to ground and resistor to 3.3v => we need to write "if(SW != 0x00000001){} or while(!(SW & 0x00000001));".
{ 
	for(i=0; i<10; i++)
	{
    IO0SET = 0x00000008; //p0.3 like output LED1.
		delay();
	  IO0CLR = 0xFFFFFFF7; // rest of pins are off.
		delay();
	}
}
else if (SW == 0x00000002)
{
	for(i=0; i<10; i++)
	{
		IO0SET = 0x00000010; // p0.4 like output LED2. 
		delay();
		IO0CLR = 0xFFFFFFEF; //rest of pins are off.
		delay();
	}
}
else if (SW == 0x00000004)
{
	for(i=0; i<10; i++)
	{
		IO0SET = 0x00000030; // p0.5
		delay(); 
		IO0CLR = 0xFFFFFFDF;
		delay();
	}
}
else if (SW == 0x80000000)
{
  for(i=0; i<10; i++)
	{
		IO0SET = 0x00000040; // p0.6
		delay();
		IO0CLR = 0xFFFFFFCF;
		delay();
	}
}
while(1);
}


// we need to write a function for delay.