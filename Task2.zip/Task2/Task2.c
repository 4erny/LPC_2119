#include <LPC21xx.h>

__irq void EINT0_isr(void); //These 2 state marks will tell the C compiler thet after the main function (main loop), there are two other functions which are also interrupt service rooutines. If we do not write these two state marks, the compiler will generate an error.
__irq void EINT1_isr(void); // __irq tells the C compiler that the functions are interrupt service routines (so it will work like hardware, not like software in polly stategi).


int main(void)
{
	//configuring the PLL for a CCLK of 60MHz but according to simulation CCLK = 58.9824MHz.    Configure PLL so that CPU clock = 60MHz and PCLK = 30 MHz.      
	
	PLLCFG = 0x00000022;  //MSEL bits = PLLCFG(4:0) and PSEL bits = PLLCFG(6:5), from pg57 M=3-1 = 2 and P= 2-1=1
	PLLCON = 0x00000001;  //enable PLL   PLLCON bit 0 is the PLLE bit which is the PLL enable bit
	
	PLLFEED = 0x000000AA; //Update PLL registers with feed sequence
	PLLFEED = 0x00000055;
	
	while(!(PLLSTAT & 0x00000400)); //wait for PLL to lock.
//PLLSTAT reg bit 10 is the PLOCK bit. if PLL has locked this bit will be SET
	
	PLLCON = 0x00000003; // bit 1 of PLLCON reg is PLL connect bit (PLLC) to connect the PLL with the system oscillator
	
	PLLFEED = 0x000000AA; //Update PLL registers with feed sequence
	PLLFEED = 0x00000055;

	VPBDIV = 0x00000002; // set the VLSI peripheral bus to 30MHz
	
	PINSEL0 = 0x000008CC; // set EINT0 and EINT1 (p0.1 and p0.3) and Match0.1(Timer0) pin 0.5. In the pinsel0 register we did not use gpious as inputs but external interrupt inputs, they are special kind of inputs. 
	IODIR0 = 0xFFFFFFF5; //set p0.1 and p0. 3 as input(because they are external interrupt input). it should be 0 because of our hardware. and p0.5 because it's connected to timer0 through tomr1 register.
	
	VICVectAddr0 = (unsigned) EINT0_isr; //assign interrupt with pin 0.1. We are pointing the external interrupt 0 - interrupt service routine to vector address 0.
	VICVectAddr1 = (unsigned) EINT1_isr; //assign interrupt with pin 0.3. We are pointing th external interrupt 1 - interrupt service routine to vector address 1.
	VICVectCntl0 = 0x0000002E; //connected addres 0 with EINT0. we are Assigning  external interrupt 0 sorce to vector address 0 and enabling the interrupt source ( bit 5).
	VICVectCntl1 = 0x0000002F; // number 2 is bit 5, it should be high.
	VICIntSelect = 0x00000000; //all selected to be vectored interrupt(medium priority)
	VICIntEnable = 0x0000C000; //have started our interrupts. We are switching ON our interrupts.
	while(1); // then everything is enabled and we have "stoped" in this point and looping here.
}

void EINT0_isr(void) __irq //when we are using interrupt service routine firstly we need to disable it and than when we leave the loop, we need to switch, make it enable again. We are complimenting the state in top(that they are match).
{
	VICIntEnClr = 0x00004000; //disable bit 14. EINT0.
	T0TCR = 2; // reset Timer 0. high on bit 2. Counter is not enabled yet.
	T0CTCR = 0; // Timer 0 is an internal timer counting counting PCLK cycles.
	T0PR = 5; // 30MHz divided by (T0PR+1) which is 30Mhz / 6
	T0MR1 =  2500000; // 0.5 seconds delay
	T0MCR = 0x00000010; // reset timer 0 when we match with MR1.
	T0EMR = 0x000000C0; // toggle p0.5 when timer 0 matches match register 1. p242 of datasheet.
	T0TCR = 1; // start timer 0. p237
	VICIntEnable = 0x00004000; //enable EINT0 again.
}

void EINT1_isr(void) __irq
{
	VICIntEnClr = 0x00008000; //switch of EINT1.
	T0TCR = 2; //switch of timer 0. p237
	VICIntEnable = 0x00008000; //enable EINT1.
}


void onesec(void)
{
	unsigned long i;
	for (i=0; i<10000000; i++)
	{
		//do nothing
	}
}
