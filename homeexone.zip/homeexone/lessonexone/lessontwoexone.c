#include <LPC21xx.h>
#define SW (1<<16)  // symbol switch represent the number where 1 shifted to the left 16time. Now it doesn't mean any value right now for any port, it's just a number on the symbol SW.
#define LED0 (1<<16) // same as previous

//declaring function to generate a delay
void delay_ms(long time);

int main (void)
{ 
	long state = 0; // using a variable to check the switch sw.
	//configuring pins as GPIOs.
	PINSEL0 = 0x00000000; //configure from P0.0 to P0.15
	PINSEL1 = 0x00000000; //configure from P0.16 to P0.31
	PINSEL2 = 0x00000000; //configure from P1.16 to P1.31 can be used only as GPIOs
	
	IODIR0 = LED0; //configure P0.0 to P0.3 as output. all other pins are still input.
	IODIR1 = 0x00000000;// all pins 1( P1.0 etc) is now input.
	
	while(1)
	{
		state = IOPIN1 & SW; // doing bitwise operation the result will be stored in the variable state. Apply bitwise and operation and .
		if(state != SW) // if variable state is not equal to variable sw, we will do the loop, if not we will not do this loop because of the hardware( when the switch is closed logic low, when the switch is open is logic high, that is why we have this equation, because we want to do our loop when our switch is pressed.
		{
		IOCLR0 = LED0; // clear LED0 (pin 0.16, logic low) we coul even write (1<<16) or the number like 0x000etc, or even SW because it's same as LED0. 
    delay_ms(20); // in this configuration we start from logic low and our duty cycle for low is 20 ms
	  IOSET0 = LED0; // set LED0 (pin 0.16 logic high)
	  delay_ms(2); //for logic high 2 ms
		}
	}		
}
//Definition
void delay_ms(long time)
{
	long x = 0;
	for(x=0; x<time; x++)
	{
	  VPBDIV = 1;//It means that CCLK will be divided by 1, therefore PCLK = CCLK.
	  T0PR = 5; //It means that Prescaler Register is 5.
	  T0TC = 0; //Timer counter starts from 0, count number of tics.
	  T0MR0 = 10000;// Number of ticks required for 1 milli second
	  T0MCR = 4; // to stop the counter after we get 10000 ticks.  Stop on match and reset TC.
		T0TCR = 1; // enable Timer 0.
	  while(T0MR0 != T0TC); // loop until there is a match.
		T0TCR = 0; // Disable Timer 0.
	}
}